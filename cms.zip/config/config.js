module.exports ={
    db:{
        host:'localhost',
        user:'cms',
        port:3306,
        password:'6138148',
        database:'mycms'
       }
}
